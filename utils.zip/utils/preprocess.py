import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import MinMaxScaler
from scipy.linalg import sqrtm

def load_and_process(src_path, tgt_path, feature_cols, window_size=10, batch_size=64):
    def process_csv(path):
        df = pd.read_csv(path)
        df = df.replace([np.inf, -np.inf], np.nan).fillna(df.median())
        x = MinMaxScaler().fit_transform(df[feature_cols].values)
        y = df['label'].values
        x_win, y_win = [], []
        for i in range(len(x) - window_size):
            x_win.append(x[i:i+window_size])
            y_win.append(y[i+window_size])
        return torch.FloatTensor(np.array(x_win)), torch.LongTensor(np.array(y_win))

    s_x, s_y = process_csv(src_path)
    t_x, t_y = process_csv(tgt_path)
    s_loader = DataLoader(TensorDataset(s_x, s_y), batch_size=batch_size, shuffle=True, drop_last=True)
    t_loader = DataLoader(TensorDataset(t_x, t_y), batch_size=batch_size, shuffle=True, drop_last=True)
    return s_loader, t_loader

def calculate_mmd(s, t):
    def kernel(s, t):
        n = s.size(0) + t.size(0)
        total = torch.cat([s, t], 0)
        total0 = total.unsqueeze(0).expand(total.size(0), total.size(0), total.size(1))
        total1 = total.unsqueeze(1).expand(total.size(0), total.size(0), total.size(1))
        dist = ((total0-total1)**2).sum(2)
        bw = torch.sum(dist.data) / (n**2-n)
        return sum([torch.exp(-dist / (bw * (2.0**i))) for i in range(5)])
    batch = s.size(0)
    k = kernel(s, t)
    return torch.mean(k[:batch, :batch] + k[batch:, batch:] - k[:batch, batch:] - k[batch:, :batch])

def calculate_fid(r_f, g_f):
    m1, s1 = r_f.mean(0), np.cov(r_f, rowvar=False)
    m2, s2 = g_f.mean(0), np.cov(g_f, rowvar=False)
    diff = np.sum((m1 - m2)**2)
    covm = sqrtm(s1.dot(s2))
    if np.iscomplexobj(covm): covm = covm.real
    return diff + np.trace(s1 + s2 - 2.0 * covm)