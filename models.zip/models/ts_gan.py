import torch
import torch.nn as nn

class TSGenerator(nn.Module):
    def __init__(self, input_size=42):
        super(TSGenerator, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_size, input_size * 2),
            nn.BatchNorm1d(input_size * 2),
            nn.LeakyReLU(0.2),
            nn.Linear(input_size * 2, input_size),
            nn.Tanh()
        )

    def forward(self, x):
        batch, seq, feat = x.shape
        x_flat = x.view(-1, feat)
        res = self.net(x_flat)
        out = x_flat + 0.1 * res 
        return out.view(batch, seq, feat)

class DomainDiscriminator(nn.Module):
    def __init__(self, feat_size=128):
        super(DomainDiscriminator, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(feat_size, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, 32),
            nn.LeakyReLU(0.2),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, feat):
        return self.net(feat)