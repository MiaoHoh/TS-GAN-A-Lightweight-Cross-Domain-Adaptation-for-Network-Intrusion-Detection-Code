import torch
import torch.nn as nn

class BiLSTMStudent(nn.Module):
    def __init__(self, input_size=42, hidden_size=64, num_layers=2, num_classes=2):
        super(BiLSTMStudent, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, 
                            batch_first=True, bidirectional=True, dropout=0.2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_size * 2, 32),
            nn.ReLU(),
            nn.Linear(32, num_classes)
        )

    def forward(self, x):
        out, _ = self.lstm(x)
        feat = out[:, -1, :] 
        logits = self.fc(feat)
        return logits, feat